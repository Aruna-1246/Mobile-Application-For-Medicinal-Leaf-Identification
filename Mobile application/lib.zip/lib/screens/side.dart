

















import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';


import 'capture dashborad.dart';
import 'doo.dart';
import 'ferti.dart';
import 'gallerydashboard.dart';
import 'login_screen.dart';
import 'mainn.dart';




void main() {
  runApp(new MaterialApp(
    home: new ambboard(),
  ));
}

class ambboard extends StatefulWidget {
  const ambboard({Key? key}) : super(key: key);

  @override
  State<ambboard> createState() => _DashboardState();
}

class _DashboardState extends State<ambboard> {
  var islogoutloading = false;
  late String userEmail = '';

  @override
  void initState() {
    super.initState();
    // Call the method to fetch the email in the initState

  }



  logout() async {
    setState(() {
      islogoutloading = true;
    });

    await FirebaseAuth.instance.signOut();

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => LoginView()),
    );

    setState(() {
      islogoutloading = false;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.teal[200],
        actions: [
          IconButton(
            onPressed: () {
              logout();
            },
            icon: islogoutloading
                ? CircularProgressIndicator()
                : Icon(Icons.exit_to_app),
            color: Colors.red,
          ),
        ],
      ),
      drawer: Drawer(
        child: Container(
          color: Colors.teal[500],
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              DrawerHeader(
                decoration: BoxDecoration(


                  color: Colors.teal[200],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Add icon in the header
                    Image.asset(
                      'assets/images/growth.gif', // Replace with the path to your image
                      height: 120, // Adjust the height of the image
                      width: 120, // Adjust the width of the image
                      // Optional: Set color
                    ),
                    // Add any other header content here
                  ],
                ),
              ),
              ListTile(
                leading: Icon(
                  Icons.camera, // Add your desired icon
                  color: Colors.white,
                ),
                title: Text(
                  'Capture',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                  ),
                ),
                onTap: () {


                  Navigator.pushReplacement(
                      context as BuildContext, MaterialPageRoute(builder: (context) => capture(),));





                  setState(() {
                    // Change the index or perform any other actions when the item is selected.
                  });
                },
              ),
              ListTile(
                leading: Icon(
                  Icons.browse_gallery, // Add your desired icon
                  color: Colors.white,
                ),
                title: Text(
                  'Choose from gallery',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                  ),
                ),
                onTap: () {
                  Navigator.pushReplacement(
                      context as BuildContext, MaterialPageRoute(builder: (context) => gallery(),));



                  setState(() {
                    // Change the index or perform any other actions when the item is selected.
                  });
                },
              ),

              ListTile(
                leading: Icon(
                  Icons.nature_people_sharp, // Add your desired icon
                  color: Colors.white,
                ),
                title: Text(
                  'Herbal plants',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                  ),
                ),
                onTap: () {
                  Navigator.pushReplacement(
                      context as BuildContext, MaterialPageRoute(builder: (context) => HerbalPlantsWidget(),));

                  setState(() {
                    // Change the index or perform any other actions when the item is selected.
                  });
                },
              ),













              ListTile(
                leading: Icon(
                  Icons.wechat_rounded, // Add your desired icon
                  color: Colors.white,
                ),
                title: Text(
                  'Do''s' '/' 'Dont''s',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                  ),
                ),
                onTap: () {
                   Navigator.pushReplacement(
                       context as BuildContext, MaterialPageRoute(builder: (context) => PlantInfoWidget(),));

                  setState(() {
                    // Change the index or perform any other actions when the item is selected.
                  });
                },
              ),
            ],
          ),
        ),
      ),
      body: mainn(), // Set your default page here
    );
  }
}