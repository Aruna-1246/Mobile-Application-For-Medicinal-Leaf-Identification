from django.urls import path
from . import views

urlpatterns = [
    path('', views.landingpage, name='landingpage'),
    path('register/', views.register, name='register'),
    path('login/', views.loginpage, name='login'),
    path('logout/', views.logoutusers, name='logout'),
    path('index/', views.index, name='index'),
    path('problem_statement/', views.problem_statement, name='problem_statement'),
    path('model/', views.model, name='model'),
    path('Teamates_5/', views.Teamates_5, name='Teamates_5'),
    path('model_database/', views.model_database, name='model_database'),
]
