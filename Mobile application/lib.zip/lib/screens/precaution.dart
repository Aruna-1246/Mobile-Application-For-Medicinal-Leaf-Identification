import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:permission_handler/permission_handler.dart';

class FullListPage extends StatefulWidget {
  final String initialData;

  FullListPage({
    required this.initialData,
  });

  @override
  _FullListPageState createState() => _FullListPageState();
}

class _FullListPageState extends State<FullListPage> with SingleTickerProviderStateMixin {
  String emaill = " ";
  late DatabaseReference _databaseReference;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  FlutterTts flutterTts = FlutterTts();
  @override
  void initState() {
    super.initState();

    _databaseReference = FirebaseDatabase.instance.reference().child('uses').child(widget.initialData);

    _animationController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 500),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(_animationController);

    _animationController.repeat(reverse: true);

    _databaseReference.onValue.listen((DatabaseEvent event) {
      if (event.snapshot != null) {
        Map<String, dynamic> data = Map<String, dynamic>.from(event.snapshot!.value as Map);
        String newData = data['data']?.toString() ?? "";
        setState(() {
          emaill = newData;
          _animationController.forward();
        });
      }
    });
    // _requestPermissions();



  }

  //
  // Future<void> _requestPermissions() async {
  //   Map<Permission, PermissionStatus> statuses = await [
  //     Permission.speech,
  //   ].request();
  //   print(statuses);
  // }
  //
  // Future<void> _speak(String text) async {
  //   await flutterTts.setLanguage("en-US");
  //   await flutterTts.speak(text);
  // }






  //
  //
  // Future<void> speakResponse(String? response) async {
  //   await flutterTts.setLanguage("en-US");
  //   await flutterTts.setPitch(1.0);
  //   await flutterTts.speak(response ?? 'No response');
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Precautions'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Description and Uses :',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 16),
              AnimatedBuilder(
                animation: _fadeAnimation,
                builder: (context, child) {
                  return Opacity(
                    opacity: _fadeAnimation.value,
                    child: Text(
                      emaill,
                      style: TextStyle(fontSize: 18),
                    ),
                  );
                },
              ),
              SizedBox(height: 16),
              AnimatedBuilder(
                animation: _fadeAnimation,
                builder: (context, child) {
                  return Opacity(
                    opacity: _fadeAnimation.value,
                    child: ElevatedButton(
                      onPressed: () {
                        // You can add any action on button press
                      },
                      child: Text(widget.initialData),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
}
