import 'dart:io';

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:intl/intl.dart';

void main() {
  runApp(MaterialApp(
    home: Update(),
  ));
}

class Update extends StatefulWidget {
  const Update({Key? key}) : super(key: key);

  @override
  _AddProductState createState() => _AddProductState();
}

class _AddProductState extends State<Update> {
  final TextEditingController _productNameController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController addressc = TextEditingController();
  final TextEditingController locationc = TextEditingController();
  final TextEditingController mobilec = TextEditingController();

  final TextEditingController timecontroller = TextEditingController();
  final TextEditingController datecontroller = TextEditingController();

  late String _selectedCategory = ' ';
  final List<String> _categories = ['Male', 'Female'];
  String authh = " ";
  File? _imageFile;
  DateTime currentDate = DateTime.now();
  late String name = " ";
  late String age = " ";
  late String weight = " ";
  late String height = " ";
  late String mobile = " ";

  late DatabaseReference _databaseReference;
  late String formattedDate;
  late String formattedTime;

  @override
  void initState() {
    super.initState();
    formattedDate = DateFormat('yyyy-MM-dd').format(currentDate);
    datecontroller.text = formattedDate;
    formattedTime = DateFormat('HH:mm:ss').format(currentDate);
    timecontroller.text = formattedTime;
    _selectedCategory = _categories.isNotEmpty ? _categories.first : '';

    final FirebaseAuth _auth = FirebaseAuth.instance;
    User? user = _auth.currentUser;
    String? userId = user?.uid;
    authh = userId!;
    print(authh);

    _databaseReference =
        FirebaseDatabase.instance.reference().child('Bio').child(authh);

    _databaseReference.onValue.listen((DatabaseEvent event) {
      if (event.snapshot != null && event.snapshot!.value != null) {
        Map<String, dynamic> data =
        Map<String, dynamic>.from(event.snapshot!.value as Map);
        String newData = data['name']?.toString() ?? "";
        String age = data['age']?.toString() ?? "";
        String wei = data['weight']?.toString() ?? "";
        String heu = data['height']?.toString() ?? "";
        String heuu = data['gender']?.toString() ?? "";
        String mo = data['mobile']?.toString() ?? "";

        print('dfshdhfds');

        setState(() {
          _productNameController.text = newData;
          _descriptionController.text = age;
          addressc.text = wei;
          locationc.text = heu;
          mobilec.text = mo;
          _selectedCategory = _categories.contains(heuu) ? heuu : _categories.first;
        });
      }
    });
  }

  Future<void> _saveProduct() async {
    var data = {
      "pname": _productNameController.text,
      "des": _descriptionController.text,
      "address": addressc.text,
      "location": locationc.text,
      "mobile": mobilec.text,
      "date": datecontroller.text,
      "status1": 'request',
    };

    try {
      FirebaseAuth _auth = FirebaseAuth.instance;
      User? user = _auth.currentUser;
      String? userId = user?.uid;

      DatabaseReference _database = FirebaseDatabase.instance.reference();

      await _database.child('Bio').child(userId!).set({
        "name": _productNameController.text,
        "age": _descriptionController.text,
        "weight": addressc.text,
        "height": locationc.text,
        "gender": _selectedCategory,
        "status1": 'request',
        "date": datecontroller.text,
        "pkey": userId,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Center(
            child: Text(
              'Profile Added ',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.blue,
          elevation: 4.0,
        ),
      );

      _productNameController.clear();
      _descriptionController.clear();
      addressc.clear();
      mobilec.clear();
      locationc.clear();

      setState(() {
        _imageFile = null;
      });
    } catch (e) {
      print('Error saving product: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Bio'),
        actions: [
          IconButton(
            onPressed: _saveProduct,
            icon: Icon(Icons.save),
          ),
        ],
        leading: IconButton(
          onPressed: () {
            print('Unknown Person Button Pressed');
          },
          icon: CircleAvatar(
            child: Icon(Icons.person_outline),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextFormField(
              controller: _productNameController,
              decoration: InputDecoration(labelText: 'Name'),
            ),
            TextFormField(
              controller: _descriptionController,
              decoration: InputDecoration(labelText: 'Age'),
            ),
            TextFormField(
              controller: addressc,
              decoration: InputDecoration(labelText: 'Weight (kg)'),
            ),
            TextFormField(
              controller: locationc,
              decoration: InputDecoration(labelText: 'Height (cm)'),
            ),
            DropdownButtonFormField(
              value: _selectedCategory,
              items: _categories.map((category) {
                return DropdownMenuItem(
                  value: category,
                  child: Text(category),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedCategory = value as String;
                });
              },
              decoration: InputDecoration(labelText: 'Gender'),
            ),
            TextFormField(
              controller: datecontroller,
              decoration: InputDecoration(labelText: 'Date'),
            ),
          ],
        ),
      ),
    );
  }
}
