from django.contrib import admin
from . models import UserImageModel


admin.site.register(UserImageModel)