import 'dart:io';

import 'package:flutter/material.dart';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:intl/intl.dart';


void main() {
  runApp(MaterialApp(
    home: calorie(),
  ));
}

class calorie extends StatefulWidget {
  const calorie({Key? key}) : super(key: key);

  @override
  _AddProductState createState() => _AddProductState();
}

class _AddProductState extends State<calorie> {
  String _productNameController = " ";
  String _descriptionController = " ";
  String addressc = " ";
  String locationc = " ";
  String mobilec = " ";

  String timecontroller = " ";
  String datecontroller = " ";

  late String _selectedCategory;
  final List<String> _categories = [
    'Fruits',
    'Vegetables',
    'Nuts & spices',
    'Cereals'
  ];
  String authh = " ";
  File? _imageFile;
  DateTime currentDate = DateTime.now();
  String name = " ";
  String age = " ";

  String weight = " ";

  String height = " ";
  String mobile = " ";
  int agee = 0;
  int heightt = 0;
  int weightt = 0;

  double bmr = 0;


  late DatabaseReference _databaseReference;
  late String formattedDate;
  late String formattedTime;

  @override
  void initState() {
    super.initState();
    // Formatting the current date into a single string with the desired format
    formattedDate = DateFormat('yyyy-MM-dd').format(currentDate);
    datecontroller = formattedDate;
    // Use the formatted date as needed
    print('Formatted Date: $formattedDate');
    formattedTime = DateFormat('HH:mm:ss').format(currentDate);
    timecontroller = formattedTime;
    final FirebaseAuth _auth = FirebaseAuth.instance;
    User? user = _auth.currentUser;
    String? userId = user?.uid;
    authh = userId!;
    print(authh);

    _databaseReference =
        FirebaseDatabase.instance.reference().child('Bio').child(authh);

    _databaseReference.onValue.listen((DatabaseEvent event) {
      if (event.snapshot != null && event.snapshot!.value != null) {
        Map<String, dynamic> data =
        Map<String, dynamic>.from(event.snapshot!.value as Map);
        String newData = data['name']?.toString() ?? "";
        String age = data['age']?.toString() ?? "";
        String wei = data['weight']?.toString() ?? "";
        String heu = data['height']?.toString() ?? "";
        String gen = data['gender']?.toString() ?? "";
        String mo = data['mobile']?.toString() ?? "";

        print('dfshdhfds');

        weightt = int.tryParse(wei) ?? 0; // Default to 0 if conversion fails
        heightt = int.tryParse(heu) ?? 0; // Default to 0 if conversion fails
        agee = int.tryParse(age) ?? 0; // Default to 0 if conversion fails

        if (gen == 'Male') {
          bmr =
              88.362 + (13.397 * weightt) + (4.799 * heightt) - (5.677 * agee);
        } else if (gen == 'Female') {
          bmr =
              447.593 + (13.397 * weightt) + (4.799 * heightt) - (5.677 * agee);
        }

        setState(() {
          _productNameController = newData;
          _descriptionController = age;
          addressc = wei;
          locationc = heu;
          mobilec = mo;
        });
      }
    });
  }

  //
  // Future<void> _saveProduct() async {
  //   var data = {
  //     "pname": _productNameController.text,
  //     "des": _descriptionController.text,
  //     "address": addressc.text,
  //     "location": locationc.text,
  //     "mobile": mobilec.text,
  //
  //
  //     "date": datecontroller.text,
  //     "status1": 'request',
  //
  //   };
  //
  //   try {
  //     FirebaseAuth _auth = FirebaseAuth.instance;
  //     User? user = _auth.currentUser;
  //     String? userId = user?.uid;
  //
  //
  //
  //     DatabaseReference _database = FirebaseDatabase.instance.reference();
  //
  //     await _database.child('Bio').child(userId!).set({
  //       "name": _productNameController.text,
  //       "age": _descriptionController.text,
  //       "weight": addressc.text,
  //       "height": mobilec.text,
  //       "location": locationc.text,
  //       "status1": 'request',
  //
  //
  //       "date": datecontroller.text,
  //
  //       "pkey": userId,
  //     });
  //
  //     ScaffoldMessenger.of(context).showSnackBar(
  //       SnackBar(
  //         content: Center(
  //           child: Text(
  //             'Profile Added ',
  //             style: TextStyle(
  //               color: Colors.white,
  //               fontSize: 16.0,
  //               fontWeight: FontWeight.bold,
  //             ),
  //           ),
  //         ),
  //         behavior: SnackBarBehavior.floating,
  //         backgroundColor: Colors.blue,
  //         elevation: 4.0,
  //       ),
  //     );
  //
  //     _productNameController.clear();
  //     _descriptionController.clear();
  //     addressc.clear();
  //     mobilec.clear();
  //     locationc.clear();
  //
  //
  //
  //
  //     setState(() {
  //       _imageFile = null;
  //     });
  //   } catch (e) {
  //     print('Error saving product: $e');
  //     // Handle error saving product
  //   }
  // }
  void _additionalAction() {
    // Navigate to the additional screen when the button is pressed
    // Navigator.push(
    //   context,
    //   MaterialPageRoute(builder: (context) => unknownperson()),
    // );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('BMR Calculator'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Name: $_productNameController',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            Text(
              'Age: $_descriptionController',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            Text(
              'Weight: $addressc kg',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            Text(
              'Height: $locationc cm',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            if (bmr != 0)
              Card(

              color:Colors.blueAccent,
                elevation: 5,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15.0),
                ),
                child: Column(
                  children: [
                    Image.asset(
                      "assets/images/calories.gif",
                      width: double.infinity, // Full width of the card
                      height: 400,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Text(
                        'BMR: $bmr',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}