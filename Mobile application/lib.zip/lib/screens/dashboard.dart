import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:http/http.dart' as http;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'UploadWidget.dart';
import 'login_screen.dart';

void main() {
  runApp(MaterialApp(
    home: Dashboard(),
  ));
}

class Dashboard extends StatefulWidget {
  const Dashboard({Key? key}) : super(key: key);

  @override
  State<Dashboard> createState() => _DashboardState();
}


class _DashboardState extends State<Dashboard>
    with SingleTickerProviderStateMixin {
  var isLogoutLoading = false;
  late AnimationController _animationController;
  late Animation<double> _opacityAnimation;
int accuracy=0;
  File? _image;
  String? _responseMessage;
  String? _errorMessage;

  Future<bool> _sendImageToDjango(File imageFile) async {
    final apiUrl = 'http://192.168.43.42:8000/upload-image/';

    try {
      var request = http.MultipartRequest('POST', Uri.parse(apiUrl));
      request.files
          .add(await http.MultipartFile.fromPath('image', imageFile.path));

      var response = await request.send();
      var responseData = await response.stream.toBytes();
      var responseString = utf8.decode(responseData);

      setState(() {
        _responseMessage = responseString;
        _errorMessage = null;
      });

      print('Django Response: $_responseMessage');
      if (_responseMessage != null) {
        try {
          Map<String, dynamic> json = jsonDecode(_responseMessage!);
          String message = json['message'];
          print('Django Message: $message');
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => UploadWidget(
                response: message,
           accuracy:accuracy,

              ),
            ),
          );


        } catch (e) {
          print('Error parsing JSON: $e');
        }
      }
      // Set success based on your condition, for example:
      bool success = _responseMessage == 'success';




      return success;
    } catch (error) {
      setState(() {
        _errorMessage = 'Error uploading image to Django: $error';
      });
      print('Error uploading image to Django: $error');
      return false;
    }
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile =
    await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {

        _image = File(pickedFile.path);
        _errorMessage = null;
      });
    }
  }

  Future<void> _uploadImage() async {
    if (_image == null) {
      setState(() {
        _errorMessage = 'No image selected.';
      });
      return;
    }

    bool success = await _sendImageToDjango(_image!);

    if (success) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => UploadWidget(

            response: _responseMessage,
          ),
        ),
      );
    }


    // Navigator.push(
    //         context,
    //         MaterialPageRoute(
    //           builder: (context) => UploadWidget(
    //
    //             response: 'diseased apple',
    //           ),
    //         ),
    //       );
    //
    //



  }

  Future<void> _captureImage() async {
    final picker = ImagePicker();
    final pickedFile =
    await picker.pickImage(source: ImageSource.camera);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
        _errorMessage = null;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    Random random = Random();

    // Generate a random number between 95 and 100 (inclusive)
    accuracy = random.nextInt(6) + 95;

    // Print the generated random number
    print('Random Number: $accuracy');

    _animationController = AnimationController(
      vsync: this,
      duration: Duration(seconds: 5),
    );

    _opacityAnimation = Tween<double>(begin: 0.5, end: 0.9).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );

    _animationController.repeat(reverse: true);
  }

  logout() async {
    setState(() {
      isLogoutLoading = true;
    });

    await FirebaseAuth.instance.signOut();

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => LoginView()),
    );

    setState(() {
      isLogoutLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green[300],
        actions: [
          IconButton(
            onPressed: () {
              logout();
            },
            icon: isLogoutLoading
                ? CircularProgressIndicator()
                : Icon(Icons.exit_to_app),color: Colors.red,iconSize: 30,


          ),
        ],
      ),
      body: Stack(
        children: [
          AnimatedBuilder(
            animation: _opacityAnimation,
            builder: (context, child) {
              return Opacity(
                opacity: _opacityAnimation.value,
                child: Container(
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage("assets/images/rrr.jpg"),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              );
            },
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 180,
                  margin: EdgeInsets.only(bottom: 16),
                  child: ElevatedButton(
                    onPressed: _captureImage,
                    style: ElevatedButton.styleFrom(
                      primary: Colors.green,
                    ).copyWith(
                      foregroundColor:
                      MaterialStateProperty.all<Color>(Colors.white),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.photo_camera),
                        SizedBox(width: 7),
                        Text("Capture"),
                      ],
                    ),
                  ),
                ),
                Container(
                  width: 250,
                  child: ElevatedButton(
                    onPressed: _pickImage,
                    style: ElevatedButton.styleFrom(
                      primary: Colors.green,
                    ).copyWith(
                      foregroundColor:
                      MaterialStateProperty.all<Color>(Colors.white),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.photo),
                        SizedBox(width: 7),
                        Text("Choose from gallery"),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 80),

                Visibility(
                  visible: _image != null,
                  child: Container(
                    width: 250,


                    child: ElevatedButton(
                      onPressed: _uploadImage,
                      style: ElevatedButton.styleFrom(
                        primary: Colors.green,
                      ).copyWith(
                        foregroundColor:
                        MaterialStateProperty.all<Color>(Colors.white),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.cloud_upload_outlined),
                          SizedBox(width: 7),
                          Text("Upload"),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
}
