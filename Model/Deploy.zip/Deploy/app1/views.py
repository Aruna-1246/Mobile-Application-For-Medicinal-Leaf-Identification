from django.shortcuts import redirect, render
from django.contrib.auth import authenticate, login,logout
from . forms import CreateUserForm
from django.contrib import messages
from . models import UserImageModel
from PIL import Image, ImageOps
from tensorflow import keras
import numpy as np
from . import forms
    
def register(request):
    form = CreateUserForm()
    if request.method =='POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            form.save()
            user = form.cleaned_data.get('username')
            messages.success(request, 'Account was successfully created. ' + user)
            return redirect('login')

    context = {'form':form}
    return render(request, '2_register.html', context)


def loginpage(request):
    if request.method =='POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('index')
        else:
            messages.info(request, 'Username OR Password incorrect')

    context = {}
    return render(request,'3_login.html', context)

def logoutusers(request):
    logout(request)
    return redirect('login')

def index(request):
    return render(request, '4_home.html')

def landingpage(request):
    return render(request, '1_landingpage.html')

def problem_statement(request):
    return render(request, '5_problem_statement.html')

def Teamates_5(request):
    return render(request,'5_Teamates.html')

def model(request):
    print("HI")
    if request.method == "POST":
        form = forms.UserImageForm(files=request.FILES)
        if form.is_valid():
            print('HIFORM')
            form.save()
        obj = form.instance
        result1 = UserImageModel.objects.latest('id')
        models = keras.models.load_model('C:/Users/SPIRO25/Desktop/HERBAL/HERBAL/Deploy/app1/mobile_net.h5')
        data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)
        image = Image.open("C:/Users/SPIRO25/Desktop/HERBAL/HERBAL/Deploy/media/images/" + str(result1)).convert("RGB")
        size = (224, 224)
        image = ImageOps.fit(image, size, Image.ANTIALIAS)
        image_array = np.asarray(image)
        normalized_image_array = (image_array.astype(np.float32) / 127.0) - 1
        data[0] = normalized_image_array
        classes = ['Aloevera','Amruthaballi','ashoka','Badipala','Bamboo','Betel','Bringaraja','Caricature','Castor','Citron_lime',
                   'Coffee','Coriender','Curry','Drumstick','Eucalyptus','Ginger','Guava','Hibiscus','Insulin','Kambajala','Lantana',
                   'Lemon','Mango','Neem','Nelavembu','Onion','Palak','Papaya','Parijatha','Pomoegranate','Pumpkin','Tamarind',
                   'Taro','Thumbe','Tomato','Tulsi']
        prediction = models.predict(data)
        idd = np.argmax(prediction)
        a = (classes[idd])
        if a == 'Aloevera':
            a = 'Aloe vera, a versatile herb, is renowned for its succulent leaves containing a gel-like substance rich in antioxidants, vitamins, and minerals. It\'s widely used in skincare, aiding in soothing burns and moisturizing skin, and also offers potential health benefits when ingested.'
        elif a == 'Amruthaballi':
            a = 'Amruthaballi, also known as Indian Pennywort, is a herbaceous plant that is believed to have various medicinal properties. It is often used in traditional medicine for its potential health benefits.'
        elif a == 'ashoka':
            a = 'Ashoka, also known as Saraca indica, is a tree with significant cultural and religious importance in India. It is revered for its beautiful flowers and is associated with various medicinal uses.'
        elif a == 'Badipala':
            a = 'Badipala, also known as Palmyra palm, is a species of palm native to the Indian subcontinent. It is valued for its versatile uses, including food, shelter, and traditional medicine.'
        elif a == 'Bamboo':
            a = 'Bamboo, a fast-growing woody grass, is known for its strength, flexibility, and sustainability. It has various uses ranging from construction material to culinary delicacies.'
        elif a == 'Betel':
            a = 'Betel, also known as Piper betle, is a vine belonging to the Piperaceae family. Its leaves are often chewed with areca nut and slaked lime as a stimulant in many parts of Asia.'
        elif a == 'Bringaraja':
            a = 'Bringaraja, also known as False Daisy, is a plant with a long history of use in traditional medicine, particularly in Ayurveda. It is believed to have various health benefits.'
        elif a == 'Caricature':
            a = 'Caricature, also known as Ceratonia siliqua, is a flowering evergreen tree native to the Mediterranean region. Its pods, commonly known as carob, are used as a natural sweetener.'
        elif a == 'Castor':
            a = 'Castor, also known as Ricinus communis, is a fast-growing perennial shrub with various industrial and medicinal uses. Its seeds contain ricin, a toxic compound, but also yield castor oil.'
        elif a == 'Citron_lime':
            a = 'Citron lime, also known as Citrus medica var. sarcodactylis, is a unique citrus fruit with finger-like segments. It is valued for its aromatic zest and refreshing flavor.'
        elif a == 'Coffee':
            a = 'Coffee, derived from the roasted seeds of Coffea plants, is one of the most popular beverages worldwide. It is cherished for its stimulating effects and rich, complex flavors.'
        elif a == 'Coriender':
            a = 'Coriander, also known as Coriandrum sativum, is an aromatic herb used in various cuisines around the world. Its seeds and leaves are prized for their distinct flavor.'
        elif a == 'Curry':
            a = 'Curry, a generic term for a variety of dishes originating from the Indian subcontinent, typically involves a complex blend of spices and herbs. It is a cornerstone of Indian cuisine.'
        elif a == 'Drumstick':
            a = 'Drumstick, also known as Moringa oleifera, is a nutrient-rich plant native to the Indian subcontinent. Its leaves, pods, and seeds are valued for their nutritional properties.'
        elif a == 'Eucalyptus':
            a = 'Eucalyptus, a genus of trees and shrubs native to Australia, is known for its distinct aroma and medicinal properties. Its essential oil is widely used for respiratory ailments.'
        elif a == 'Ginger':
            a = 'Ginger, a flowering plant in the Zingiberaceae family, is valued for its culinary and medicinal properties. It is renowned for its spicy flavor and potential health benefits.'
        elif a == 'Guava':
            a = 'Guava, a tropical fruit native to Central America, is prized for its sweet and fragrant flesh. It is rich in vitamin C and antioxidants, making it a nutritious snack.'
        elif a == 'Hibiscus':
            a = 'Hibiscus, a genus of flowering plants in the Malvaceae family, is known for its showy flowers and potential medicinal uses. Hibiscus tea is popular for its tart flavor and health benefits.'
        elif a == 'Insulin':
            a = 'Insulin, a hormone produced by the pancreas, plays a crucial role in regulating blood sugar levels. It is essential for metabolism and energy regulation in the body.'
        elif a == 'Kambajala':
            a = 'Kambajala, also known as Lagerstroemia speciosa, is a species of flowering plant native to Southeast Asia. Its flowers are used in traditional medicine for various purposes.'
        elif a == 'Lantana':
            a = 'Lantana, a genus of flowering plants in the Verbenaceae family, is prized for its colorful blooms and ability to attract butterflies. Some species have medicinal properties.'
        elif a == 'Lemon':
            a = 'Lemon, a citrus fruit native to Asia, is valued for its acidic juice and aromatic zest. It is used in culinary, medicinal, and cleaning applications.'
        elif a == 'Mango':
            a = 'Mango, often hailed as the "king of fruits," is a tropical fruit prized for its sweet, juicy flesh and rich flavor. It is enjoyed fresh, in smoothies, desserts, and more.'
        elif a == 'Neem':
            a = 'Neem, also known as Azadirachta indica, is a tree native to the Indian subcontinent. Its leaves, seeds, and bark are used in traditional medicine and organic farming.'
        elif a == 'Nelavembu':
            a = 'Nelavembu, also known as Andrographis paniculata, is a medicinal herb native to South Asia. It is valued for its immune-boosting and anti-inflammatory properties.'
        elif a == 'Onion':
            a = 'Onion, a staple vegetable in cuisines worldwide, is prized for its pungent flavor and culinary versatility. It is used in soups, salads, stir-fries, and various other dishes.'
        elif a == 'Palak':
            a = 'Palak, also known as spinach, is a leafy green vegetable rich in nutrients like iron, vitamins, and antioxidants. It is valued for its versatility in cooking and health benefits.'
        elif a == 'Papaya':
            a = 'Papaya, a tropical fruit native to the Americas, is prized for its sweet, orange flesh and digestive enzymes. It is enjoyed fresh, in salads, smoothies, and savory dishes.'
        elif a == 'Parijatha':
            a = 'Parijatha, also known as Nyctanthes arbor-tristis, is a flowering plant native to Southeast Asia. Its fragrant flowers are used in traditional medicine and religious ceremonies.'
        elif a == 'Pomoegranate':
            a = 'Pomegranate, a fruit-bearing shrub or small tree, is prized for its juicy, ruby-red arils and antioxidant properties. It is enjoyed fresh, in juices, salads, and desserts.'
        elif a == 'Pumpkin':
            a = 'Pumpkin, a type of winter squash, is prized for its sweet, earthy flavor and dense, nutrient-rich flesh. It is used in soups, pies, curries, and various other dishes.'
        elif a == 'Tamarind':
            a = 'Tamarind, a tropical fruit-bearing tree, is prized for its sweet-sour pulp and culinary versatility. It is used in various cuisines for its tangy flavor and digestive properties.'
        elif a == 'Taro':
            a = 'Taro, a starchy root vegetable native to Southeast Asia, is valued for its nutty flavor and versatile uses. It can be boiled, fried, steamed, or mashed.'
        elif a == 'Thumbe':
            a = 'Thumbe, also known as Leucas aspera, is a medicinal herb native to the Indian subcontinent. It is used in traditional medicine for its anti-inflammatory and analgesic properties.'
        elif a == 'Tomato':
            a = 'Tomato, a savory fruit commonly mistaken for a vegetable, is prized for its juicy flesh and tangy flavor. It is used in salads, sauces, soups, and numerous other dishes.'
        elif a == 'Tulsi':
            a = 'Tulsi, also known as Holy Basil, is a sacred plant in Hinduism revered for its medicinal properties. It is used in Ayurveda for its immune-boosting and stress-relieving properties.'
        data = UserImageModel.objects.latest('id')
        data.label = a
        data.save()
        return render(request, 'output.html',{'form':form,'obj':obj,'predict':a})
    else:
        form = forms.UserImageForm()
    return render(request, 'model.html',{'form':form})

def model_database(request):
    models = UserImageModel.objects.all()
    return render(request, 'model_database.html', {'models':models})
    
