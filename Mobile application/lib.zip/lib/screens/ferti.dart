import 'package:flutter/material.dart';
import 'package:herbalplants/screens/side.dart';

class HerbalPlantsWidget extends StatelessWidget {
  final List<HerbalPlant> herbalPlants = [
    HerbalPlant(
      name: 'Lavender',
      imageUrl: 'assets/images/laven.jpg',
      description:
      'Lavender is a fragrant herb known for its calming properties.',
      uses: 'It is used in aromatherapy and for its medicinal properties.',
    ),
    HerbalPlant(
      name: 'Peppermint',
      imageUrl: 'assets/images/pepp.jpg',
      description:
      'Peppermint is a refreshing herb with a cooling sensation.',
      uses:
      'It is used in teas, cooking, and as a natural remedy for digestive issues.',
    ),
    // Add more herbal plants as needed

    HerbalPlant(
      name: 'Echinacea ',
      imageUrl: 'assets/images/ech.jpg',
      description:
      'Echinacea is a flowering herb native to North America, known for its striking purple petals and prominent spiky center.',
      uses:
      'It is commonly used to boost the immune system and reduce the duration and severity of colds and flu. Echinacea supplements are available in various forms, including teas, tinctures, and capsules.',
    ),

    HerbalPlant(
      name: 'Chamomile  ',
      imageUrl: 'assets/images/cham.jpg',
      description:
      'Chamomile is a daisy-like herb with small white flowers and feathery leaves.',
      uses:
      'It is prized for its calming properties and is often consumed as a tea to promote relaxation and improve sleep quality. Chamomile can also be used topically to soothe skin irritations such as eczema and sunburn.',
    ),


    HerbalPlant(
      name: 'Ginger   ',
      imageUrl: 'assets/images/gin.jpg',
      description:
      'Ginger is a tropical plant with thick, knobby rhizomes and long green leaves.',
      uses:
      'It is widely used as a culinary spice and has a long history of medicinal use for its anti-inflammatory and digestive properties. Ginger tea is commonly consumed to alleviate nausea, motion sickness, and indigestion.',
    ),

    HerbalPlant(
      name: 'Turmeric    ',
      imageUrl: 'assets/images/tur.jpg',
      description:
      'Turmeric is a rhizomatous herbaceous perennial plant with striking orange-yellow rhizomes and lance-shaped leaves.',
      uses:
      'It is prized for its anti-inflammatory and antioxidant properties. Turmeric is commonly used in cooking, particularly in Indian cuisine, and is also available in supplement form for its potential health benefits, including reducing inflammation and improving joint health.',
    ),


    HerbalPlant(
      name: 'Rosemary     ',
      imageUrl: 'assets/images/ros.jpg',
      description:
      ' Rosemary is an aromatic evergreen shrub with needle-like leaves and small blue flowers.',
      uses:
      'It is often used as a culinary herb to add flavor to dishes, particularly meats and roasted vegetables. Rosemary oil is also used in aromatherapy for its stimulating and invigorating properties. Additionally, rosemary tea is believed to improve digestion and cognitive function.',
    ),














    HerbalPlant(
      name: 'Aloe Vera',
      imageUrl: 'assets/images/aloe.jpg',
      description:
      'Aloe vera is a succulent plant known for its thick, fleshy leaves containing a gel-like substance.',
      uses:
      'It is commonly used topically to soothe sunburn, minor burns, and skin irritations. Aloe vera gel is also used in skincare products for its moisturizing and healing properties.',
    ),

    HerbalPlant(
      name: 'Sage',
      imageUrl: 'assets/images/sage.jpg',
      description:
      'Sage is an aromatic herb with gray-green leaves and a woody stem.',
      uses:
      'It is used in cooking to add flavor to dishes, particularly meats and stuffing. Sage tea is also consumed for its potential health benefits, including improving digestion and cognitive function.',
    ),

    HerbalPlant(
      name: 'Thyme',
      imageUrl: 'assets/images/thyme.jpg',
      description:
      'Thyme is a small perennial herb with tiny leaves and pink or purple flowers.',
      uses:
      'It is commonly used as a culinary herb, adding flavor to soups, stews, and sauces. Thyme tea is believed to have antimicrobial properties and may help alleviate coughs and sore throats.',
    ),

    HerbalPlant(
      name: 'Lemon Balm',
      imageUrl: 'assets/images/lemonbalm.jpg',
      description:
      'Lemon balm is a member of the mint family with a lemony scent and flavor.',
      uses:
      'It is used in teas and culinary dishes for its refreshing flavor. Lemon balm is also believed to have calming effects and is used to reduce stress and anxiety.',
    ),

    HerbalPlant(
      name: 'Lemongrass',
      imageUrl: 'assets/images/lemongrass.jpg',
      description:
      'Lemongrass is a tall, perennial grass with a lemony scent and flavor.',
      uses:
      'It is used in cooking, particularly in Asian cuisine, to add citrusy flavor to dishes. Lemongrass tea is consumed for its potential health benefits, including aiding digestion and reducing inflammation.',
    ),

    HerbalPlant(
      name: 'Garlic',
      imageUrl: 'assets/images/garlic.jpg',
      description:
      'Garlic is a bulbous plant with a strong, pungent flavor and aroma.',
      uses:
      'It is used as a seasoning in various cuisines worldwide and is believed to have numerous health benefits, including boosting the immune system, reducing blood pressure, and improving heart health.',
    ),

    HerbalPlant(
      name: 'Basil',
      imageUrl: 'assets/images/Basil.jpg',
      description:
      'Basil is an aromatic herb with green, oval-shaped leaves and a sweet, peppery flavor.',
      uses:
      'It is used in cooking, particularly in Italian cuisine, to add flavor to dishes such as pasta, pizza, and salads. Basil is also used in traditional medicine for its potential antibacterial and anti-inflammatory properties.',
    ),

    HerbalPlant(
      name: 'Oregano',
      imageUrl: 'assets/images/Oregano.jpg',
      description:
      'Oregano is a perennial herb with small, oval-shaped leaves and pink or purple flowers.',
      uses:
      'It is used as a culinary herb, particularly in Mediterranean cuisine, to add flavor to dishes such as pizza, pasta, and grilled meats. Oregano is also believed to have antimicrobial properties and may help alleviate respiratory issues.',
    ),

    HerbalPlant(
      name: 'Cilantro (Coriander)',
      imageUrl: 'assets/images/Cilantro.jpg',
      description:
      'Cilantro, also known as coriander, is an aromatic herb with flat, parsley-like leaves and small white flowers.',
      uses:
      'It is used in cooking, particularly in Latin American, Asian, and Middle Eastern cuisines, to add flavor to dishes such as salsa, curry, and stir-fries. Cilantro is also used in traditional medicine for its potential digestive and anti-inflammatory properties.',
    ),

    HerbalPlant(
      name: 'Mint',
      imageUrl: 'assets/images/Mint.jpg',
      description:
      'Mint is a perennial herb with bright green, serrated leaves and a refreshing, menthol aroma.',
      uses:
      'It is used in cooking, beverages, and desserts for its cooling flavor. Mint tea is consumed for its potential digestive benefits, and mint oil is used in aromatherapy for its invigorating properties.',
    ),







































  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
       backgroundColor:Colors.indigo[400] ,
        title: Text('Herbal Plants'),

        leading: IconButton(
          icon: Icon(Icons.arrow_back), // Custom back icon
          onPressed: () {
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) =>  ambboard(),));
          },
        ),





      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/soil55.png'),
            fit: BoxFit.cover,
          ),
        ),
        child: ListView.builder(
          itemCount: herbalPlants.length,
          itemBuilder: (context, index) {
            return HerbalPlantCard(
              herbalPlant: herbalPlants[index],
            );
          },
        ),
      ),
    );
  }
}

class HerbalPlant {
  final String name;
  final String imageUrl;
  final String description;
  final String uses;

  HerbalPlant({
    required this.name,
    required this.imageUrl,
    required this.description,
    required this.uses,
  });
}

class HerbalPlantCard extends StatelessWidget {
  final HerbalPlant herbalPlant;

  const HerbalPlantCard({required this.herbalPlant});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Image.asset(
            herbalPlant.imageUrl,
            height: 200,
            fit: BoxFit.cover,
          ),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  herbalPlant.name,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: 8.0),
                Text(
                  'Description: ${herbalPlant.description}',
                  style: TextStyle(fontSize: 16.0),
                ),
                SizedBox(height: 8.0),
                Text(
                  'Uses: ${herbalPlant.uses}',
                  style: TextStyle(fontSize: 16.0),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: HerbalPlantsWidget(),
  ));
}
