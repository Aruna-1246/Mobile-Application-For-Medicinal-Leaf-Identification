// import 'package:flutter/material.dart';
// import 'package:flutter_tts/flutter_tts.dart';
//
//
// import 'package:permission_handler/permission_handler.dart';
// import 'package:plantdisease/screens/precaution.dart';
//
//
//
//
//
// class UploadWidget extends StatelessWidget {
//   final String? response;
//
//   UploadWidget({Key? key, this.response}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Upload Widget'),
//       ),
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             SizedBox(height: 16),
//             Text(
//               'Response:',
//               style: TextStyle(fontSize: 20),
//             ),
//             AnimatedResponseText(response: response),
//             if (response == 'diseased apple' || response == 'diseased banana' || response == 'diseased orange'
//
//             )
//               ElevatedButton(
//                 onPressed: () {
//                   // Fetch data from Firebase Realtime Database
//                   Navigator.push(
//                     context,
//                     MaterialPageRoute(
//                       builder: (context) =>
//                           FullListPage(
//                             initialData: response!,
//
//
//
//
//
//
//
//                             // Pass other fields as needed
//
//
//
//                           ),
//                     ),
//                   );
//                 },
//                 child: Text('Show Precautions'),
//               ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   void fetchDataFromFirebase(BuildContext context) {
//     // Fetch data from Firebase Realtime Database here
//     // Replace the following line with your actual implementation
//     // For example, you can use a FutureBuilder to fetch data asynchronously
//
//   }
// }
//
// class PrecautionsScreen extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Precautions'),
//       ),
//       body: SingleChildScrollView(
//         child: Column(
//           children: [
//             // Your fetched data will be displayed here
//             // Replace the following line with your actual implementation
//             // For example, you can use a PDF package to display the PDF content
//             Text('Fetched Data from Firebase'),
//           ],
//         ),
//       ),
//     );
//   }
// }
//
// class AnimatedResponseText extends StatefulWidget {
//   final String? response;
//
//   AnimatedResponseText({Key? key, this.response}) : super(key: key);
//
//   @override
//   _AnimatedResponseTextState createState() => _AnimatedResponseTextState();
// }
//
// class _AnimatedResponseTextState extends State<AnimatedResponseText>
//     with SingleTickerProviderStateMixin {
//   late AnimationController _animationController;
//   late Animation<double> _sizeAnimation;
//   late Animation<double> _opacityAnimation;
//
//   String? accuracy=" ";
//   late Animation<Color?> _colorAnimation;
//   FlutterTts flutterTts = FlutterTts();
//   @override
//   void initState() {
//     super.initState();
//
//     _animationController = AnimationController(
//       vsync: this,
//       duration: Duration(seconds: 1),
//     );
//
//     _sizeAnimation = TweenSequence([
//       TweenSequenceItem(tween: Tween(begin: 20.0, end: 30.0), weight: 1),
//       TweenSequenceItem(tween: Tween(begin: 30.0, end: 20.0), weight: 1),
//     ]).animate(_animationController);
//
//     _opacityAnimation = TweenSequence([
//       TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.0), weight: 1),
//       TweenSequenceItem(tween: Tween(begin: 0.0, end: 1.0), weight: 1),
//     ]).animate(_animationController);
//
//     _colorAnimation = ColorTween(
//       begin: Colors.black,
//       end: Colors.red,
//     ).animate(_animationController);
//
//     _animationController.repeat();
//     _requestPermissions();
//
//   String? spea=widget.response;
//
//     List<String>? fruits = spea?.split(',');
//     String? secondFruit = fruits?[1];
//   accuracy = fruits?[2];
//
//     _speak(secondFruit!);
//   }
//
//
//
//
//   Future<void> _requestPermissions() async {
//     Map<Permission, PermissionStatus> statuses = await [
//       Permission.speech,
//     ].request();
//     print(statuses);
//   }
//   Future<void> _speak(String text) async {
//     await flutterTts.setLanguage("en-US");
//     await flutterTts.speak(text ?? 'No response');
//   }
//
//
//
//
//
// // Update the function to accept a nullable string
//   Future<void> speakResponse(String? response) async {
//     await flutterTts.setLanguage("en-US");
//     await flutterTts.setPitch(1.0);
//     await flutterTts.speak(response ?? 'No response');
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return AnimatedBuilder(
//       animation: _animationController,
//       builder: (context, child) {
//         return Text(
//           widget.response != null ? '${widget.response} - Accuracy: ${accuracy ?? "Unknown"}' : 'No response',
//           style: TextStyle(
//             fontSize: _sizeAnimation.value ?? 20.0,
//             fontWeight: FontWeight.bold,
//             color: _colorAnimation.value ?? Colors.black,
//             decoration: TextDecoration.none,
//           ),
//         );
//       },
//     );
//   }
//
//
//   @override
//   void dispose() {
//     _animationController.dispose();
//     super.dispose();
//   }
// }













































import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:herbalplants/screens/precaution.dart';
import 'package:permission_handler/permission_handler.dart';






class UploadWidget extends StatelessWidget {
  final String? response;
  final int? accuracy;
  UploadWidget({Key? key, this.response,this.accuracy}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
    body: Container(
    decoration: BoxDecoration(
    image: DecorationImage(
    image: AssetImage("assets/images/plant.png"), // Replace with your image path
    fit: BoxFit.cover,
    ),
    ),



        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 16),
              Text(
                'Result:',
                style: TextStyle(fontSize: 16),
              ),
              AnimatedResponseText(response: response),
              SizedBox(height: 16),
              // Text(
              //   'Accuracy: $accuracy%',
              //   style: TextStyle(fontSize: 29,color: Colors.green,fontWeight: FontWeight.bold),
              // ),
              if (response == 'Aloevera' ||
                  response == 'Amruthaballi' ||
                  response == 'ashoka' ||
                  response == 'Badipala' ||
                  response == 'Bamboo' ||
              response == 'Betel' ||
              response == 'Bringaraja' ||
              response == 'Caricature' ||
              response == 'Castor' ||
              response == 'Citron_lime' ||

              response == 'Coffee' ||
              response == 'Coriender' ||
              response == 'Curry' ||
                  response == 'Drumstick' ||
                  response == 'Eucalyptus' ||

                  response == 'Ginger' ||
                  response == 'Guava' ||
                  response == 'Hibiscus' ||

                  response == 'Insulin' ||

                  response == 'Kambajala' ||

                  response == 'Lantana' ||
                  response == 'Lemon' ||
                  response == 'Mango' ||
                  response == 'Neem' ||

                  response == 'Nelavembu' ||

                  response == 'Onion' ||
                  response == 'Palak' ||
                  response == 'Papaya' ||

                  response == 'Parijatha' ||

                  response == 'Pomoegranate' ||

                  response == 'Pumpkin' ||

                  response == 'Tamarind' ||

                  response == 'Taro' ||
                  response == 'Thumbe' ||

                  response == 'Tomato' ||
                  response == 'Tulsi'















              )
        ElevatedButton(
        onPressed: () {
      // Fetch data from Firebase Realtime Database
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) =>
              FullListPage(
                initialData: response!,







                // Pass other fields as needed



              ),
        ),
      );
    },
    child: Text('Show Uses'),
    ),
    ],
    ),
    ),
    ));
  }
  void fetchDataFromFirebase(BuildContext context) {
    // Fetch data from Firebase Realtime Database here
    // Replace the following line with your actual implementation
    // For example, you can use a FutureBuilder to fetch data asynchronously

  }
}

class PrecautionsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Precautions'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Your fetched data will be displayed here
            // Replace the following line with your actual implementation
            // For example, you can use a PDF package to display the PDF content
            Text('Fetched Data from Firebase'),
          ],
        ),
      ),
    );
  }
}
class AnimatedResponseText extends StatefulWidget {
  final String? response;

  AnimatedResponseText({Key? key, this.response}) : super(key: key);

  @override
  _AnimatedResponseTextState createState() => _AnimatedResponseTextState();
}

class _AnimatedResponseTextState extends State<AnimatedResponseText>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _sizeAnimation;
  late Animation<double> _opacityAnimation;
  int accuracy=0;

  late Animation<Color?> _colorAnimation;
  FlutterTts flutterTts = FlutterTts();
  @override
  void initState() {
    super.initState();















    _animationController = AnimationController(
      vsync: this,
      duration: Duration(seconds: 1),
    );

    _sizeAnimation = TweenSequence([
      TweenSequenceItem(tween: Tween(begin: 20.0, end: 30.0), weight: 1),
      TweenSequenceItem(tween: Tween(begin: 30.0, end: 20.0), weight: 1),
    ]).animate(_animationController);

    _opacityAnimation = TweenSequence([
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.0), weight: 1),
      TweenSequenceItem(tween: Tween(begin: 0.0, end: 1.0), weight: 1),
    ]).animate(_animationController);

    _colorAnimation = ColorTween(
      begin: Colors.black,
      end: Colors.red,
    ).animate(_animationController);

    _animationController.repeat();


  String? spea=widget.response;

  //   List<String>? fruits = spea?.split(',');
  //   String? secondFruit = fruits?[1];
  // accuracy = fruits?[2];


  }




  Future<void> _requestPermissions() async {
    Map<Permission, PermissionStatus> statuses = await [
      Permission.speech,
    ].request();
    print(statuses);
  }
  Future<void> _speak(String text) async {
    await flutterTts.setLanguage("en-US");
    await flutterTts.speak(text ?? 'No response');
  }





// Update the function to accept a nullable string
  Future<void> speakResponse(String? response) async {
    await flutterTts.setLanguage("en-US");
    await flutterTts.setPitch(1.0);
    await flutterTts.speak(response ?? 'No response');
  }



  @override
  Widget build(BuildContext context) {
    // Check if the response is "Banana Healthy Leaf"
    if (widget.response == 'APPLE HEALTHY LEAF' ||  widget.response == 'GRAPE HEALTHY LEAF' ||
        widget.response == 'POTATO HEALTHY LEAF' ||
        widget.response == 'STRAWBERRY HEALTHY LEAF' ||   widget.response == 'TOMATO HEALTHY LEAF') {
      return Container(
        color: Colors.green, // Set green background color
        child: Text(
          widget.response ?? 'No response',
          style: TextStyle(
            fontSize: 20.0, // Fixed font size for healthy leaf
            fontWeight: FontWeight.bold,
            color: Colors.white, // Set text color to white
            decoration: TextDecoration.none,
          ),
        ),
      );
    }

    return AnimatedBuilder(
      animation: _animationController,
      builder: (context, child) {
        return Text(
          widget.response ?? 'No response',
          style: TextStyle(
            fontSize: _sizeAnimation.value ?? 20.0,
            fontWeight: FontWeight.bold,
            color: _colorAnimation.value ?? Colors.black,
            decoration: TextDecoration.none,
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
}
