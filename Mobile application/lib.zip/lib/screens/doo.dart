import 'package:flutter/material.dart';
import 'package:herbalplants/screens/side.dart';

void main() {
  runApp(MaterialApp(
    home: PlantInfoWidget(),
  ));
}

class PlantInfoWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

       backgroundColor: Colors.indigo[400],
        title: Text('Herbal Plant Care Tips'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => ambboard()),
            ); // Handle back navigation here
          },
        ),
      ),
      backgroundColor: Colors.grey[300],
      body: SingleChildScrollView( // Wrap with SingleChildScrollView
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.asset(
                'assets/images/ppw.jpg', // Replace with your plant image path
                height: 300,
                width: 300,
              ),
              SizedBox(height: 20),
              Text(
                'Dos and Don\'ts for Herbal Plant Care',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Dos:',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      '1. Provide proper sunlight exposure according to the specific needs of each herbal plant.',
                      style: TextStyle(fontSize: 16),
                    ),
                    Text(
                      '2. Water your herbal plants regularly, ensuring that the soil remains moist but not waterlogged.',
                      style: TextStyle(fontSize: 16),
                    ),
                    Text(
                      '3. Use organic fertilizers suitable for herbal plants in moderation to promote healthy growth.',
                      style: TextStyle(fontSize: 16),
                    ),
                    SizedBox(height: 20),
                    Text(
                      'Don\'ts:',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      '1. Avoid placing herbal plants in areas with excessive direct sunlight, as it may lead to sunburn or drying out.',
                      style: TextStyle(fontSize: 16),
                    ),
                    Text(
                      '2. Do not overwater herbal plants, as it can cause root rot and other moisture-related issues.',
                      style: TextStyle(fontSize: 16),
                    ),
                    Text(
                      '3. Avoid using chemical pesticides or herbicides near herbal plants, as they may harm beneficial insects and affect plant health.',
                      style: TextStyle(fontSize: 16),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
