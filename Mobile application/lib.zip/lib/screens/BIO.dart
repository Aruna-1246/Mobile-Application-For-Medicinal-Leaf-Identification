import 'dart:io';

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:herbalplants/screens/update.dart';


import 'package:intl/intl.dart';

void main() {
  runApp(MaterialApp(
    home: BIO(),
  ));
}

class BIO extends StatefulWidget {
  const BIO({Key? key}) : super(key: key);

  @override
  _AddProductState createState() => _AddProductState();
}

class _AddProductState extends State<BIO> {

  late String _selectedCategory = 'Male';

  final TextEditingController _productNameController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController addressc = TextEditingController();
  final TextEditingController locationc = TextEditingController();
  final TextEditingController mobilec = TextEditingController();

  final TextEditingController timecontroller = TextEditingController();
  final TextEditingController datecontroller = TextEditingController();

  final List<String> _categories = ['Male', 'Female']; // Added gender options

  File? _imageFile;
  DateTime currentDate = DateTime.now();
  late String formattedDate;
  late String formattedTime;

  @override
  void initState() {
    super.initState();
    formattedDate = DateFormat('yyyy-MM-dd').format(currentDate);
    datecontroller.text = formattedDate;
    formattedTime = DateFormat('HH:mm:ss').format(currentDate);
    timecontroller.text = formattedTime;
  }

  Future<void> _saveProduct() async {
    var data = {
      "pname": _productNameController.text,
      "des": _descriptionController.text,
      "address": addressc.text,
      "location": locationc.text,

      "gender": _selectedCategory, // Added gender to data

      "date": datecontroller.text,
      "status1": 'request',
    };

    try {
      FirebaseAuth _auth = FirebaseAuth.instance;
      User? user = _auth.currentUser;
      String? userId = user?.uid;

      DatabaseReference _database = FirebaseDatabase.instance.reference();

      await _database.child('Bio').child(userId!).set({
        "name": _productNameController.text,
        "age": _descriptionController.text,
        "weight": addressc.text,
        "height": locationc.text,
        "gender": _selectedCategory, // Added gender to database

        "status1": 'request',
        "date": datecontroller.text,
        "pkey": userId,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Center(
            child: Text(
              'Profile Added ',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.blue,
          elevation: 4.0,
        ),
      );

      _productNameController.clear();
      _descriptionController.clear();
      addressc.clear();
      mobilec.clear();
      locationc.clear();

      setState(() {
        _imageFile = null;
      });
    } catch (e) {
      print('Error saving product: $e');
      // Handle error saving product
    }
  }

  void _additionalAction() {
    // Navigate to the additional screen when the button is pressed
    // Navigator.push(
    //   context,
    //   MaterialPageRoute(builder: (context) => unknownperson()),
    // );

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) =>
            Update(








              // Pass other fields as needed



            ),
      ),
    );


  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Bio'),
        actions: [
          IconButton(
            onPressed: _saveProduct,
            icon: Icon(Icons.save),
          ),
          ElevatedButton(
            onPressed:



            _additionalAction,
            child: Text('Update'),
          ),
        ],
        leading: IconButton(
          onPressed: () {
            // Implement action for the unknown person button





            print('Unknown Person Button Pressed');
          },
          icon: CircleAvatar(
            child: Icon(Icons.person_outline),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextFormField(
              controller: _productNameController,
              decoration: InputDecoration(labelText: 'Name'),
            ),
            TextFormField(
              controller: _descriptionController,
              decoration: InputDecoration(labelText: 'Age'),
            ),
            TextFormField(
              controller: addressc,
              decoration: InputDecoration(labelText: 'Weight (kg)'),
            ),
            TextFormField(
              controller: locationc,
              decoration: InputDecoration(labelText: 'Height (cm)'),
            ),

            DropdownButtonFormField(
              value: _selectedCategory,
              items: _categories.map((category) {
                return DropdownMenuItem(
                  value: category,
                  child: Text(category),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedCategory = value as String;
                });
              },
              decoration: InputDecoration(labelText: 'Gender'),
            ),
            TextFormField(
              controller: datecontroller,
              decoration: InputDecoration(labelText: 'Date'),
            ),
          ],
        ),
      ),
    );
  }
}
