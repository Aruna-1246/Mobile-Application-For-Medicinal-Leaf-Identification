from django.db import models

class DataModel(models.Model):

    nitrogen = models.CharField(max_length=100)
    phosphorus = models.CharField(max_length=100)
    potasium = models.CharField(max_length=100)
    temperature = models.CharField(max_length=100)
    humidity = models.CharField(max_length=100)
    ph = models.CharField(max_length=100)
    rainfall = models.CharField(max_length=100)
    label = models.CharField(max_length=100)

def __str__(self):
    return self.nitrogen, self.phosphorus, self.potasium,self.temperature,self.humidity,self.ph,self.rainfall,self.label
