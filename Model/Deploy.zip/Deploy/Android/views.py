from django.shortcuts import render
from django.views import View

class Android(View):
    def get(self,request):
        return render(request,"1_landingpage.html")

from PIL import Image
import numpy as np
from django.http import JsonResponse
from keras.models import load_model
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

@csrf_exempt
@require_POST
def upload_image(request):
    if 'image' in request.FILES:
        uploaded_image = request.FILES['image']
        processed_image = process_image(uploaded_image)
        print(processed_image)
        result = make_prediction(processed_image)
        print(result)
        response_data = {'message': result}
        print(response_data)
        return JsonResponse(response_data, status=201)

    else:
        response_data = {'error': 'No image provided'}
        print(response_data)
        return JsonResponse(response_data, status=400)
    
from PIL import Image, ImageOps
from tensorflow import keras

def process_image(uploaded_image):
    image = Image.open(uploaded_image).convert("RGB")
    image = image.resize((224, 224))
    size = (224, 224)
    image = ImageOps.fit(image, size, Image.ANTIALIAS)
    image_array = np.asarray(image)
    print("Image processing is working")
    return image_array
 
model_path = 'C:/Users/SPIRO25/Desktop/HERBAL/HERBAL/Deploy/Android/mobile_net.h5'
model = load_model(model_path)

def make_prediction(processed_image):
    data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)
    normalized_image_array = (processed_image.astype(np.float32) / 127.0) - 1
    print(normalized_image_array)
    data[0] = normalized_image_array
    print(data)
    prediction = model.predict(data)
    print(prediction)
    result = process_prediction(prediction)
    print("Model building is working")
    print(result)
    return result

def process_prediction(prediction):
    classes = ['Aloevera','Amruthaballi','ashoka','Badipala','Bamboo','Betel','Bringaraja','Caricature','Castor','Citron_lime',
                'Coffee','Coriender','Curry','Drumstick','Eucalyptus','Ginger','Guava','Hibiscus','Insulin','Kambajala','Lantana',
                'Lemon','Mango','Neem','Nelavembu','Onion','Palak','Papaya','Parijatha','Pomoegranate','Pumpkin','Tamarind',
                'Taro','Thumbe','Tomato','Tulsi']
    predicted_class_index = np.argmax(prediction)
    print(predicted_class_index)
    predicted_class = classes[predicted_class_index]
    print(predicted_class)
    return predicted_class

