import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'BIO.dart';
import 'dashboard.dart';
import 'login_screen.dart';

void main() {
  runApp(MaterialApp(
    home: userboard(),
  ));
}

class userboard extends StatefulWidget {
  const userboard({Key? key}) : super(key: key);

  @override
  State<userboard> createState() => _DashboardState();
}

class _DashboardState extends State<userboard> {
  var islogoutloading = false;
  int _currentIndex = 0;
  final List<Widget> _pages = [
    Dashboard(),
  ];

  logout() async {
    setState(() {
      islogoutloading = true;
    });

    await FirebaseAuth.instance.signOut();

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => LoginView()),
    );

    setState(() {
      islogoutloading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blueAccent,
        automaticallyImplyLeading: false,
        actions: [
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => BIO()),
              );
            },
            child: Container(
              padding: EdgeInsets.all(8.0),
              child: Text(
                'Add',
                style: TextStyle(
                  color: Colors.indigo,
                  fontSize: 16.0,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              logout();
            },
            child: Text(
              'Logout',
              style: TextStyle(
                color: Colors.indigo,
                fontSize: 16.0,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
      body: _pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: [
          BottomNavigationBarItem(
            icon: Flexible(
              child: Align(
                alignment: Alignment.centerRight,
                child: Icon(Icons.home),
              ),
            ),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: SizedBox.shrink(), // Dummy invisible item
            label: '',
          ),
        ],
        selectedItemColor: Colors.indigo,
        unselectedItemColor: Colors.grey,
        backgroundColor: Colors.white,
        elevation: 10,
        selectedLabelStyle: TextStyle(fontWeight: FontWeight.bold),
        unselectedLabelStyle: TextStyle(fontWeight: FontWeight.normal),
      ),
    );
  }
}


class RightAlignedBottomNavigationBarItem extends StatelessWidget {
  final String label;
  final IconData icon;

  const RightAlignedBottomNavigationBarItem({
    required this.label,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon),
        Flexible(
          child: Align(
            alignment: Alignment.centerRight,
            child: Padding(
              padding: const EdgeInsets.only(right: 8.0),
              child: Text(
                label,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 12.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}