package com.example.herbalplants;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
